<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src=""></script>
</head>
<body>  
    <div><a href=""><span>Bienvenido 
        
    </span></a></div>
    <div>

    </div>
    <div><a href=""><span></span></a></div>
</body>
</html>


<?php /**PATH C:\Users\PERCY\Desktop\General\Laravel\crudApi\resources\views/login.blade.php ENDPATH**/ ?>